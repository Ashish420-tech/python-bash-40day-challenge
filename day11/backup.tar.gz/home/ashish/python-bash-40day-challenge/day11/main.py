import math_utils

print(math_utils.add(10,5))
print(math_utils.sub(10,5))
